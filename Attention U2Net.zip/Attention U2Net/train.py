# !/usr/bin/python
# -*- coding:utf-8 -*-
# @Time     : 2021/12/23 17:55
# @Author   : Yang Jiaxiong  2625398619@qq.com  yangjiaxiong@whut.edu.cn
# @File     : train.py

import glob
import os

import torch
import torch.optim as optim
from torch.autograd import Variable
from torch.utils.data import DataLoader
from torchvision import transforms

from model import *
from util import RandomCrop, SalObjDataset, RescaleT, ToTensorLab

if __name__ == '__main__':
    # ------- 1. define loss function --------
    from util.loss import multi_mix_loss_fusion as loss_fnc

    # from util.loss import multi_bce_loss_fusion as loss_fnc

    # ------- 2. set the directory of training dataset --------
    model_name = 'AGCA5Stage'  # 'attu2net' 'u2net' 'AGCAOutsideRef' 'AGCAInsideRef'

    print(model_name)
    data_dir = os.path.join(os.getcwd(), 'train_data' + os.sep)
    tra_image_dir = os.path.join('DUTS-TR', 'imgs' + os.sep)
    tra_label_dir = os.path.join('DUTS-TR', 'gt' + os.sep)

    image_ext = '.jpg'
    label_ext = '.png'

    model_dir = os.path.join(os.getcwd(), 'saved_models', model_name + os.sep)

    # hyper-param
    epoch_num = 100000
    batch_size_train = 10  # the larger the better
    batch_size_val = 1
    train_num = 0
    val_num = 0

    tra_img_name_list = glob.glob(data_dir + tra_image_dir + '*' + image_ext)

    tra_lbl_name_list = []
    for img_path in tra_img_name_list:
        img_name = img_path.split(os.sep)[-1]

        aaa = img_name.split(".")
        bbb = aaa[0:-1]
        imidx = bbb[0]
        for i in range(1, len(bbb)):
            imidx = imidx + "." + bbb[i]

        tra_lbl_name_list.append(data_dir + tra_label_dir + imidx + label_ext)

    print("---")
    print("train images: ", len(tra_img_name_list))
    print("train labels: ", len(tra_lbl_name_list))
    print("---")

    train_num = len(tra_img_name_list)

    salobj_dataset = SalObjDataset(
        img_name_list=tra_img_name_list,
        lbl_name_list=tra_lbl_name_list,
        transform=transforms.Compose([  # 组合式变形
            RescaleT(320),
            RandomCrop(288),
            ToTensorLab(flag=0)]))
    salobj_dataloader = DataLoader(salobj_dataset, batch_size=batch_size_train, shuffle=True, num_workers=1)

    # ------- 3. define model --------
    # define the net
    if model_name == 'attu2net':
        net = AttU2Net(3, 1)
    elif model_name == 'attu2netboth':
        net = AttU2NetBoth(3, 1)
    elif model_name == 'attu2netoutside':
        net = AttU2NetOutside(3, 1)
    elif model_name == 'AGCAInside':
        net = AGCAInside(3, 1)
    elif model_name == 'AGCAOutside':
        net = AGCAOutside(3, 1)
    elif model_name == 'AGCABoth':
        net = AGCABoth(3, 1)
    elif model_name == 'AGInsideCAOutside':
        net = AGInsideCAOutside(3, 1)
    elif model_name == 'PACAOutside':
        net = PACAOutside(3, 1)
    elif model_name == 'AGCAInsidePro':
        net = AGCAInsidePro(3, 1)
    elif model_name == 'AGCAInsideRef':
        net = AGCAInsideRef(3, 1)
    elif model_name == 'AGCABothRef':
        net = AGCABothRef(3, 1)
    elif model_name == 'NewNet':
        net = NewNet(3, 1)
    elif model_name == 'AGCA5Stage':
        net = AGCA5Stage(3, 1)
    else:  # model_name == 'u2net'
        net = U2NET(3, 1)

    save_frq = 200  # save the model every 200 iterations if run with cpu

    if torch.cuda.is_available():
        save_frq = 1500  # save the model every 1500 iterations if run with gpu
        net.cuda()

    # ------- 4. define optimizer --------
    print("---define optimizer...")
    optimizer = optim.Adam(net.parameters(), lr=0.001, betas=(0.9, 0.999), eps=1e-08, weight_decay=0)

    # ------- 5. training process --------
    print("---start training...")
    ite_num = 0
    running_loss = 0.0
    running_tar_loss = 0.0
    ite_num4val = 0

    for epoch in range(0, epoch_num):
        net.train()

        for i, data in enumerate(salobj_dataloader):
            ite_num = ite_num + 1
            ite_num4val = ite_num4val + 1

            inputs, labels = data['image'], data['label']

            inputs = inputs.type(torch.FloatTensor)
            labels = labels.type(torch.FloatTensor)

            # wrap them in Variable
            if torch.cuda.is_available():
                inputs_v, labels_v = Variable(inputs.cuda(), requires_grad=False), Variable(labels.cuda(),
                                                                                            requires_grad=False)
            else:
                inputs_v, labels_v = Variable(inputs, requires_grad=False), Variable(labels, requires_grad=False)

            # y zero the parameter gradients
            optimizer.zero_grad()

            # forward + backward + optimize
            d0, d1, d2, d3, d4, d5, d6 = net(inputs_v)
            loss2, loss = loss_fnc(d0, d1, d2, d3, d4, d5, d6, labels_v)
            # 其中loss2保存的是最后一个SMap的loss，而loss保存的是所有SMap的loss

            loss.backward()
            optimizer.step()

            running_loss += loss.data.item()
            running_tar_loss += loss2.data.item()

            # del temporary outputs and loss
            del d0, d1, d2, d3, d4, d5, d6, loss2, loss

            print(model_name + "[epoch: %3d/%3d, batch: %5d/%5d, ite: %d] train loss: %3f, tar: %3f " % (
                epoch + 1, epoch_num, (i + 1) * batch_size_train, train_num, ite_num, running_loss / ite_num4val,
                running_tar_loss / ite_num4val))

            if ite_num % save_frq == 0:  # Over-All checkpoint
                torch.save(
                    {'epoch': epoch,
                     'ite_num': ite_num,
                     'net_state_dict': net.state_dict(),
                     'optimizer_state_dict': optimizer.state_dict()
                     },
                    model_dir + model_name + "_bce_itr_%d_train_%3f_tar_%3f.pth" % (
                        ite_num, running_loss / ite_num4val, running_tar_loss / ite_num4val)
                )
                running_loss = 0.0
                running_tar_loss = 0.0
                net.train()  # resume train
                ite_num4val = 0
